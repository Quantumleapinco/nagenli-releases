@echo off
rem Puts Nagenli on a Samsung TV. See the instructions file next to this one.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
